package AKT_8PUZZLE;

public enum facing {
    LEFT , RIGHT , UP , DOWN , STAY
}
